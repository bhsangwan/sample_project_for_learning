package com.studentapp.beans;

import java.util.Objects;

public class Course {

	private int c_id;
	private String c_name;
	private int fee;
	
	public Course() {}

	public Course(int c_id, String c_name, int fee) {
		super();
		this.c_id = c_id;
		this.c_name = c_name;
		this.fee = fee;
	}

	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}
	
	public String toString() {
		return c_name+" | "+c_id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(c_id, c_name, fee);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		return c_id == other.c_id && Objects.equals(c_name, other.c_name) && fee == other.fee;
	}
	
	
}
