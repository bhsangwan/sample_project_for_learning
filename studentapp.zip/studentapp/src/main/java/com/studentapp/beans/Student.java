package com.studentapp.beans;

import java.util.Objects;

public class Student {

	private int s_id;
	private String s_name;
	private String s_lname;
	private String s_email;
	private int s_reg_no;
	private Course cousre;
	
	public Student() {}

	public Student(int s_id, String s_name, String s_lname, String s_email, int s_reg_no, Course cousre) {
		super();
		this.s_id = s_id;
		this.s_name = s_name;
		this.s_lname = s_lname;
		this.s_email = s_email;
		this.s_reg_no = s_reg_no;
		this.cousre = cousre;
	}

	public int getS_id() {
		return s_id;
	}

	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_lname() {
		return s_lname;
	}

	public void setS_lname(String s_lname) {
		this.s_lname = s_lname;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public int getS_reg_no() {
		return s_reg_no;
	}

	public void setS_reg_no(int s_reg_no) {
		this.s_reg_no = s_reg_no;
	}

	public Course getCousre() {
		return cousre;
	}

	public void setCousre(Course cousre) {
		this.cousre = cousre;
	}
	
	public String toString() {
		return s_name+" | "+s_id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cousre, s_email, s_id, s_lname, s_name, s_reg_no);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(cousre, other.cousre) && Objects.equals(s_email, other.s_email) && s_id == other.s_id
				&& Objects.equals(s_lname, other.s_lname) && Objects.equals(s_name, other.s_name)
				&& s_reg_no == other.s_reg_no;
	}
	
	
}
