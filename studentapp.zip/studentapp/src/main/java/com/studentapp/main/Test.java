package com.studentapp.main;

import java.util.List;

import com.studentapp.beans.Course;
import com.studentapp.utils.CourseUtils;
import com.studentapp.utils.CourseUtilsImpl;

public class Test {

	public static void main(String[] args) {
		/*
		 * Course course = new Course(0, "Java", 12000);
		 * 
		 * CourseUtils utils = new CourseUtilsImpl();
		 * 
		 * if(utils.addCourse(course)) System.out.println("Course Added successfully");
		 * else System.out.println("gdbd..!");
		 */
		CourseUtils utils = new CourseUtilsImpl();
		/*
		 * Course course = utils.getCourse(100);
		 * 
		 * if(course != null)
		 * System.out.println(course.getC_id()+" | "+course.getC_name()+" | "+course.
		 * getFee()); else System.out.println("Sorry No course found with this ID..!");
		 */
		
		/*
		 * List<Course> courses = utils.getAllCourse();
		 * 
		 * for(Course course : courses) {
		 * System.out.println(course.getC_id()+" | "+course.getC_name()+" | "+course.
		 * getFee()); }
		 */
		
		Course course = new Course(101, "PHP Advance", 15500);
		
		Course updatedCourse = utils.updateCourse(course);
		
		if(updatedCourse != null)
			System.out.println(course.getC_id()+" | "+course.getC_name()+" | "+course.getFee());
		else
			System.out.println("No updated course found..!");
	}

}
