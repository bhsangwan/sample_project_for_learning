package com.studentapp.utils;

import java.util.List;

import com.studentapp.beans.Course;

public interface CourseUtils {

	public boolean addCourse(Course course);
	
	public Course getCourse(int c_id);
	
	public boolean deleteCourse(int c_id);
	
	public List<Course> getAllCourse();
	
	public Course updateCourse(Course course);
	
}
