package com.studentapp.utils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.studentapp.beans.Course;

public class CourseUtilsImpl implements CourseUtils{
	
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String username = "system";
	private static final String password = "root";
	private String driverClassName = "oracle.jdbc.driver.OracleDriver";
	
	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	@Override
	public boolean addCourse(Course course) {
		boolean courseAdded = false;
		try {
			
			//STEP 1 -- create the connection
			Class.forName(driverClassName);	//load the vendor driver class in JVM on runtime
			conn = DriverManager.getConnection(URL, username, password);
			
			String query = "INSERT INTO app_course (c_name, c_fee) VALUES (? ,?)";
			
			//STEP 2
			pst = conn.prepareStatement(query);
			
			pst.setString(1, course.getC_name());
			pst.setInt(2, course.getFee());
			
			//STEP 3
		    int rows =	pst.executeUpdate();
		    
		    if(rows > 0) {
		    	System.out.println("Course Added Successfully..!");
		    	courseAdded = true;
		    }
		    else { 
		    	System.out.println("Something went wrong..try again.");
		    }
			
		    //STEP 4
		    conn.close();
		    
		}catch(SQLException e) {
			System.out.println("Some problem while getting connected with DB");
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			System.out.println("Driver class could not be loaded..!");
		}
		return courseAdded;
	}

	@Override
	public Course getCourse(int c_id) {
		Course course = null;
		try {
			//STEP 1 -- create the connection
			Class.forName(driverClassName);	//load the vendor driver class in JVM on runtime
			conn = DriverManager.getConnection(URL, username, password);
			
			String query = "SELECT * FROM app_course WHERE c_id = ?";
			
			pst = conn.prepareStatement(query);
			pst.setInt(1, c_id);
			
			rs = pst.executeQuery();
			
			if(rs.next()) {
				/*
				 * course = new Course(); course.setC_id(rs.getInt(1));
				 * course.setC_name(rs.getString(2)); course.setFee(rs.getInt(3));
				 */
				course = new Course(rs.getInt(1), rs.getString(2),rs.getInt(3));
			}
			
			conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return course;
	}

	@Override
	public boolean deleteCourse(int c_id) {
		boolean courseDeleted = false;
		//STEP 1 -- create the connection
		try {
		Class.forName(driverClassName);	//load the vendor driver class in JVM on runtime
		conn = DriverManager.getConnection(URL, username, password);
		
		String query = "DELETE FROM app_course WHERE c_id=?";
		
		//STEP 2
		pst = conn.prepareStatement(query);
		
		pst.setInt(1, c_id);
		
		//STEP 3
	    int rows =	pst.executeUpdate();
	    
	    if(rows > 0) {
	    	courseDeleted = true;
	    }
	    else { 
	    	System.out.println("Something went wrong..try again.");
	    }
		
	    //STEP 4
	    conn.close();
		
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return courseDeleted;
	}

	@Override
	public List<Course> getAllCourse() {
		List<Course> courses = new ArrayList<Course>();
		Course course = null;
		try {
			//STEP 1 -- create the connection
			Class.forName(driverClassName);	//load the vendor driver class in JVM on runtime
			conn = DriverManager.getConnection(URL, username, password);
			
			String query = "SELECT * FROM app_course";
			
			pst = conn.prepareStatement(query);
			//stmt = conn.createStatement();
			//pst.setInt(1, c_id);
			
			rs = pst.executeQuery();
			
			while(rs.next()) {
				/*
				 * course = new Course(); course.setC_id(rs.getInt(1));
				 * course.setC_name(rs.getString(2)); course.setFee(rs.getInt(3));
				 */
				course = new Course(rs.getInt(1), rs.getString(2),rs.getInt(3));
				courses.add(course);
			}
			
			conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return courses;
	}

	@Override
	public Course updateCourse(Course course) {
		//Course updatedCourse = null;
		boolean courseUpdated = false;
		try {
			
			//STEP 1 -- create the connection
			Class.forName(driverClassName);	//load the vendor driver class in JVM on runtime
			conn = DriverManager.getConnection(URL, username, password);
			
			String query = "UPDATE app_course SET c_name=?, c_fee=? WHERE c_id=?";
			
			//STEP 2
			pst = conn.prepareStatement(query);
			
			pst.setString(1, course.getC_name());
			pst.setInt(2, course.getFee());
			pst.setInt(3, course.getC_id());
			
			//STEP 3
		    int rows =	pst.executeUpdate();
		    
		    if(rows > 0) 
		    	courseUpdated = true;
		    	
			
		    //STEP 4
		    conn.close();
		    
		    if(courseUpdated)
		    	course = getCourse(course.getC_id());
		    
		}catch(SQLException e) {
			System.out.println("Some problem while getting connected with DB");
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			System.out.println("Driver class could not be loaded..!");
		}
		return course;
	}
	

}
